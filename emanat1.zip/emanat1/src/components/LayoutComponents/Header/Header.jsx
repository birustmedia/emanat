import React from 'react'
import './Header.scss'
import Logo from '../../../assets/img/logo.svg'
import SearchIcon from '../../../assets/img/search.svg'

const Header = () => {
  return (
    <header>
      <div className="header-logo">
        <img src={Logo} alt="emanat-logo" />
      </div>

      <div className="header-search">
        <label>
          <input type="text" />

          <img src={SearchIcon} alt="emanat-axtaris" />
        </label>
      </div>

      <nav className='header-navbar'>
        <ul>
          <li>Əməkdaşlıq</li>
          <li>Terminal xəritəsi</li>
          <li>Karyera</li>
          <li>Xəbərlər</li>
          <li>Digər</li>
          {/* <li>AZ</li> */}
        </ul>
      </nav>
    </header>
  )
}

export default Header