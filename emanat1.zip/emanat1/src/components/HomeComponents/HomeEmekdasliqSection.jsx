import React from 'react'
import MainImage from '../../assets/img/home-emek-main.png'
import { Swiper, SwiperSlide } from "swiper/react";
import { Pagination } from 'swiper';
import "swiper/swiper.min.css";
import 'swiper/css/pagination';



const HomeEmekdasliqSection = () => {
    return (
        <section className='home-emekdasliq'>
            <div className="home-emekdasliq-image">
                <img src={MainImage} alt="" />
            </div>

            <div className="home-emekdasliq-main">
                <div className="home-emekdasliq-main-heading">
                    <p><span>eManat</span> ilə əməkdaşlıq</p>
                </div>

                <div className="home-emekdasliq-main-container">
                    <div className="home-emekdasliq-main-container-description">
                        <p>Ödəniş etdiyiniz anda provayder ödəniş barəsində məlumat alacaq və məbləğ dərhal balansınıza köçürüləcək.</p>
                    </div>

                    <div className="home-main-left-btn">
                        <button>Kəşf et</button>
                    </div>
                </div>

                <div className="home-emekdasliq-main-slider">
                    <Swiper
                        modules={[Pagination]}
                        slidesPerView={3}
                        slidesPerColumn={2}
                        spaceBetween={30}
                        pagination={{
                            clickable: true
                        }}
                        className="mySwiper"
                    >
                        <SwiperSlide>
                            <div className="home-emekdasliq-main-slider-div">
                                <img src="https://www.kapitalbank.az/files/about/main/Kapital_Bank_Logo.png" alt="" />
                            </div>
                        </SwiperSlide>

                        <SwiperSlide>
                            <div className="home-emekdasliq-main-slider-div">
                                <img src="https://insure.az/public/images/partners/rabitabank.png" alt="" />
                            </div>
                        </SwiperSlide>

                        <SwiperSlide>
                            <div className="home-emekdasliq-main-slider-div">
                                <img src="https://upload.wikimedia.org/wikipedia/commons/4/4e/PASHA_Bank_Georgia_logo_%28English%29.png" alt="" />
                            </div>
                        </SwiperSlide>

                        <SwiperSlide>
                            <div className="home-emekdasliq-main-slider-div">
                                <img src="https://www.kapitalbank.az/files/about/main/Kapital_Bank_Logo.png" alt="" />
                            </div>
                        </SwiperSlide>

                        <SwiperSlide>
                            <div className="home-emekdasliq-main-slider-div">
                                <img src="https://insure.az/public/images/partners/rabitabank.png" alt="" />
                            </div>
                        </SwiperSlide>

                        <SwiperSlide>
                            <div className="home-emekdasliq-main-slider-div">
                                <img src="https://upload.wikimedia.org/wikipedia/commons/4/4e/PASHA_Bank_Georgia_logo_%28English%29.png" alt="" />
                            </div>
                        </SwiperSlide>

                        <SwiperSlide>
                            <div className="home-emekdasliq-main-slider-div">
                                <img src="https://www.kapitalbank.az/files/about/main/Kapital_Bank_Logo.png" alt="" />
                            </div>
                        </SwiperSlide>

                        <SwiperSlide>
                            <div className="home-emekdasliq-main-slider-div">
                                <img src="https://insure.az/public/images/partners/rabitabank.png" alt="" />
                            </div>
                        </SwiperSlide>

                        <SwiperSlide>
                            <div className="home-emekdasliq-main-slider-div">
                                <img src="https://upload.wikimedia.org/wikipedia/commons/4/4e/PASHA_Bank_Georgia_logo_%28English%29.png" alt="" />
                            </div>
                        </SwiperSlide>

                    </Swiper>
                </div>
            </div>
        </section>
    )
}

export default HomeEmekdasliqSection