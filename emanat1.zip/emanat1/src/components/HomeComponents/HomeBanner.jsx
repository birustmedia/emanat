import React from 'react'
import HomeBannerVector from '../../assets/img/home-bg-vectors.png'

const HomeBanner = () => {
  return (
      <main className='home-main'>
        <div className="home-main-left">
          <div className="home-main-left-heading">
            <h1>Etİbarlı ödənİşlər bİr ünvanda!</h1>
          </div>

          <div className="home-main-left-desc">
            <h2>3000-dən artıq ödənİş termİnalımızla 7/24 xİdmətİnİzdəyİk!</h2>
          </div>

          <div className="home-main-left-btn">
            <button>Kəşf et</button>
          </div>
        </div>

        <div className="home-main-right">
          <img src={HomeBannerVector} alt="" />
        </div>
    </main>
  )
}

export default HomeBanner