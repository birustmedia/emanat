import React, { Fragment } from 'react'


const AboutPage = () => {
  return (
    <Fragment>
      
    </Fragment>
  )
}

export default AboutPage