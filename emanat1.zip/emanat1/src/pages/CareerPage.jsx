import React, { Fragment } from 'react'


const CareerPage = () => {
  return (
    <Fragment>
      
    </Fragment>
  )
}

export default CareerPage