import React, { Fragment } from 'react'
import '../components/HomeComponents/Home.scss'
import HomeBanner from '../components/HomeComponents/HomeBanner'
import HomeBlackSection from '../components/HomeComponents/HomeBlackSection'
import HomeEmekdasliqSection from '../components/HomeComponents/HomeEmekdasliqSection'
import HomeFeaturesSection from '../components/HomeComponents/HomeFeaturesSection'

const HomePage = () => {
  return (
    <Fragment>
      <HomeBanner/>
      <HomeBlackSection/>
      <HomeFeaturesSection/>
      <HomeEmekdasliqSection/>
    </Fragment>
  )
}

export default HomePage